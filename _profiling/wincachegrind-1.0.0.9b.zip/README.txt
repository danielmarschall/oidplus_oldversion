WinCacheGrind
by Hendy Irawan <ceefour@gauldong.net>
Web: http://hendy.gauldong.net
WinCacheGrind page: http://dev.gauldong.net/wincachegrind

Project started: Jan 17, 2005 around 6 o'clock in the morning West Indonesia Time

Overview:
This project is a KCacheGrind-wannabe for Windows.
At least it can process cachegrind.out of xdebug-2.0.0 beta 1 for PHP.
To view version of this program please use Help, About.

Usage:
Just open a cachegrind.out file and do clicks anywhere you want.
Please do also right clicks since many things in this program are right-clickable, and some features are only accessible using a right click.
As an added bonus, you can drag and drop as many files as you want from Windows Explorer to the WinCacheGrind window. Don't get too excited dropping too many files, though :-P (WinCacheGrind loads all data into memory).

License:
This program uses GNU GPL version 2 or later license.
Please see gpl.txt for complete license.

File format:
Cachegrind.out file format is "guessed" and the guesses are described in cachegrind.out File Format.txt file.

Quirks & Known Issues:
- May (or will) not work with anything other than xdebug-2.0.0 beta 1 output.
- Constructor and destructor type is guessed and hardcoded, since there is no
  actual information whether a particular function is a constructor/destructor.
- No function parameters (non-existant information)
- The overall/merged list only filters functions, but all the displayed information
  is within global scope i.e. the number of calls, percentage, times, etc.
  are collected from the entire profile, not only inside the node/function that
  you select in the tree control.
- Any very small time value (nearing 0ms or 0%) will be displayed as "-".
  This is not a bug but it's just to clean up the user interface so you won't
  have to see lots of zeros. I think this is much nicer because you won't
  care about superlightning speed functions anyway.
- TONS OF BUGS :-P
- As of xdebug 2.0.0 beta 1 it has some odd behavior sometimes, in that it doesn't
  print "summary:" line and some functions are printed but never called, which is
  bizarre. It is okay for {main} and exit procedures/destructors, since they're
  called automatically by PHP. But this happens in ordinarily called functions,
  so I believe it is a bug in xdebug. And it also doesn't give any information
  about {main}, which is very frustrating.
  WinCacheGrind will try its best to read such files, it should give you
  accurate time values. However, in this case the call structure will definitely
  not reflect the actual run.
  Update: After some experimentation it turns out that one of the causes for
  this is usage of exit() or die() PHP function. Changing this to return()
  solves the problem. However it should be noted that return() is not a
  substitute for die/exit, especially the fact that return will only terminate
  a script if used inside the main script, not a function or an included file.
  I will try to report this to xdebug author.
- Memory leaks!!! I tried to use MemProof to fix this but I can't seem to
  use it well, and most of the time MemProof shows number of errors but
  the error list is empty. :-(
  By the way, Delphi 7 had tons of memory leaks, so I have no too big problem
  with this. :-P
- Largest file tested: 10 MB Cachegrind.out file, 8 MB memory usage
  File parsing/loading takes several seconds, but after that everything is
  quick, even column sorting, finding, etc. BTW this is a script which takes
  10 seconds to run! (it's a script to update MDB database schemas) So for
  your everyday script (which is usually less than 1 or 2 seconds runtime)
  WinCacheGrind should have no problems handling these.

Wish List:
- Graphical "time bar" on every time value
  Not that I haven't tried, but the first thing, Delphi doesn't provide much
  information for drawing owner-drawn subitems in a list view (it seems that
  we have to figure out the TRect by ourselves). And the ugliest thing is
  that when resizing a column, the column width property isn't updated until
  after the resize is done. And it doesn't even repaint!
  Any help on this will be highly appreciated.
- Add filtering options, e.g. minimum number of calls, minimum time, etc.
- Prevent Delphi from reordering the MDI child windows everytime a window
  is activated. It's so annoying! :-(
- Speed up loading. Currently I think the main speed boost would be if
  I can utilize binary search in the loading function. I'm too lazy to
  implement something like that. :-(
  Update: Now it uses JCL's string hash map, it's a bit faster than before,
  but not as fast than I'd imagine. :-(

Development:
I make no guarantee that I will continue to develop this program.
But if you plan to continue developing this project or derive a work based on this please notify me first so there won't be too many branches if there're more than one interested person.

Source Code:
To get the source code please contact me via e-mail. I am expecting some people
to be interested in developing this project so I don't want too many different
independent works based on this project.

Compiling the source:
To compile the source, you need the following libraries in addition to Delphi 7:
- JEDI Code Library + JVCL v2.10
  http://www.delphi-jedi.org/

Credits & Acknowledgments:
- Xdebug [http://www.xdebug.org]
  The thing that made me had to do this. ;-)
- KCacheGrind [http://kcachegrind.sf.net]
  If it runs on Windows (without KDE+Cygwin), I really won't have to do this.
- CacheGrind
  For the "comprehensive" file format explanation. :-P
- phpDocumentor [http://phpdocu.sourceforge.net]
  Where I steal those cute icons. :-D